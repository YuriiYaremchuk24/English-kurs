﻿using static System.Collections.Specialized.BitVector32;
using System.ComponentModel.DataAnnotations.Schema;
using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;



namespace englishpizdec.Models

{
    public class Note
    {

        public int Id { get; set; }

        [Required]
        [MaxLength(1000)]
        public string? Content { get; set; }

        [Required]
        public string? Author { get; set; }

        [Required]
        public string? Password { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
