﻿namespace englishpizdec.Models
{
    public class Login
    {
    }
}
