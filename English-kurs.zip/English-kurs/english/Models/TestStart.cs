﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace englishpizdec.Models
{
    public class TestStart
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int QuestionId { get; set; }

        [Required]
        [MaxLength(255)]
        public string QuestionText { get; set; }

        [Required]
        public Level Level { get; set; }

        [Required]
        [MaxLength(255)]
        public string OptionA { get; set; }

        [Required]
        [MaxLength(255)]
        public string OptionB { get; set; }

        [Required]
        [MaxLength(255)]
        public string OptionC { get; set; }

        [Required]
        [MaxLength(255)]
        public string OptionD { get; set; }

        [Required]
        [StringLength(1)]
        public string CorrectOption { get; set; }
    }

    public enum Level
    {
        A1,
        A2,
        B1,
        B2,
        C1,
        C2
    }
}

