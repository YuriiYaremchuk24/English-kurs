﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MySql.Data.MySqlClient;
using englishpizdec.Data;
using Microsoft.EntityFrameworkCore;
using System;
using englishpizdec.Hubs;

namespace englishpizdec
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Встановлюємо з'єднання з базою даних
            string connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    Console.WriteLine("Підключення до бази даних успішно встановлено.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Помилка підключення до бази даних: {ex.Message}");
                Console.WriteLine(ex.ToString());
            }

            // Додаємо сервіси до контейнера
            builder.Services.AddRazorPages();

            // Додаємо DbContext в контейнер служб
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseMySql(connectionString, new MySqlServerVersion(new Version(8, 0, 23)))); // Вкажіть версію MySQL

            // Додаємо SignalR до контейнера служб
            builder.Services.AddSignalR();

            var app = builder.Build();

            // Налаштовуємо HTTP pipeline
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            // Налаштовуємо маршрутизацію
            app.MapRazorPages();

            // Маршрут для SignalR
            app.MapHub<ChatHub>("/chathub");

            app.Run();
        }
    }
}
