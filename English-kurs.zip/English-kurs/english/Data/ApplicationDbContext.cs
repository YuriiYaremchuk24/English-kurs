﻿using Microsoft.EntityFrameworkCore;
using static System.Collections.Specialized.BitVector32;
using englishpizdec.Models;
using System;
using System.Threading.Tasks;
using static englishpizdec.Models.Users;

namespace englishpizdec.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
                : base(options)
        {
        }


        public DbSet<TestStart> Test { get; set; }
        public DbSet<Users> Users { get; set; }

        public DbSet<Note> Notes { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    base.OnModelCreating(modelBuilder);

        //    modelBuilder.Entity<test_start>().Property(t => t.QuestionId).ValueGeneratedOnAdd();
        //    modelBuilder.Entity<users>().Property(u => u.Id).ValueGeneratedOnAdd();
        //}
        public async Task<bool> CanConnectAsync()
        {
            try
            {
                return await this.Database.CanConnectAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка подключения к базе данных: {ex.Message}");
                return false;
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    base.OnModelCreating(modelBuilder);

        //    // Переконайтеся, що первинний ключ визначено для User
        //    modelBuilder.Entity<Users>().HasKey(u => u.Id);
        //}
    }
}
