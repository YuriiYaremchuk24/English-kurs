using englishpizdec.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace englishpizdec.Pages.Note
{
    public class NoteModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public NoteModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public englishpizdec.Models.Note Note { get; set; }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Notes.Add(Note);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Note/Note");
        }
    }
}
