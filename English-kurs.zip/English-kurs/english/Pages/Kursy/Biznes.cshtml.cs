using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace englishpizdec.Pages.Kursy
{
    public class BiznesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
