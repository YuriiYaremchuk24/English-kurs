using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace englishpizdec.Pages.Kursy
{
    public class TuristModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
