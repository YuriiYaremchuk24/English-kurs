using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace englishpizdec.Pages.Kursy
{
    public class AdvancedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
