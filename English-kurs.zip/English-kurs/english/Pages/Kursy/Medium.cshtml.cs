using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace englishpizdec.Pages.Kursy
{
    public class MediumModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
