using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;

namespace englishpizdec.Pages
{
    public class RegisterModel : PageModel
    {
        private readonly IConfiguration _configuration;

        public RegisterModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [BindProperty]
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(20, ErrorMessage = "Name can't be longer than 20 characters.")]
        public string? Name { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "Number is required.")]
        [RegularExpression(@"^[0-9]{9}$", ErrorMessage = "Phone number must be 9 digits long.")]
        public string? Number { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        public string? Email { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "Password is required.")]
        [StringLength(15, ErrorMessage = "Password can't be longer than 15 characters.")]
        public string? Password { get; set; }

        [BindProperty]
        [Required(ErrorMessage = "Role is required.")]
        public string? Role { get; set; }

        public string? Message { get; private set; }

        public bool RegistrationSuccess { get; private set; } = false; // ����������� ���������� �� false


        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            try
            {
                using (var connection = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection")))
                {
                    await connection.OpenAsync();

                    var query = "INSERT INTO applicationuser (Name, Number, Email, Password, Role) VALUES (@Name, @Number, @Email, @Password, @Role)";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", Name);
                        command.Parameters.AddWithValue("@Number", Number);
                        command.Parameters.AddWithValue("@Email", Email);
                        command.Parameters.AddWithValue("@Password", Password);
                        command.Parameters.AddWithValue("@Role", Role);

                        await command.ExecuteNonQueryAsync();
                    }
                }

                RegistrationSuccess = true; // ������������ �������� �� true
                return RedirectToPage("/Index"); // ��������������� �� ������� �������
            }
            catch (Exception ex)
            {
                Message = $"Error during registration: {ex.Message}";
            }

            return Page();
        }
    }
}