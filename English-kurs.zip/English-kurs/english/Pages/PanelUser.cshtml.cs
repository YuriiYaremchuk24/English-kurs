using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace englishpizdec.Pages
{
    public class PanelUserModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
